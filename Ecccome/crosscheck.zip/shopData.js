let shopItemsData1 = [
    {
        id: 'jjjkk',
        name: 'Joggers and hoddy',
        price: '25',
        desc : 'Great Combo',
        img : './images/1.jpg'
    },
    {
        id: 'hhhhh',
        name: 'Joggers and hoddy',
        price: '25',
        desc : 'Great Combo',
        img : './images/2.jpg'  
    },
    {
        id: 'njkkkk',
        name: 'Joggers and hoddy',
        price: '25',
        desc : 'Great Combo',
        img : './images/3.jpg'
    },
    {
        id: 'tyyuuihihio',
        name: 'Joggers and hoddy',
        price: '25',
        desc : 'Great Combo',
        img : './images/4.jpg'
    },
    {
        id: 'hfkjkf',
        name: 'Crazy Hot Joggers ',
        price: '15',
        desc : 'Just Fahion',
        img : './images/5.jpg'
    },
    {
        id: 'hgjgf',
        name: 'Crazy Hot Joggers',
        price: '15',
        desc : 'Just Fahion',
        img : './images/6.jpg'  
    },
    {
        id: 'jgkgf',
        name: 'Crazy Hot Joggers',
        price: '15',
        desc : 'Just Fahion',
        img : './images/7.jpg'
    },
    {
        id: 'mnmgfgfg',
        name: 'Crazy Hot Joggers',
        price: '15',
        desc : 'Just Fahion',
        img : './images/8.jpg'
    }
    
]



// i was having issue with this part that is why i didn't complete the project
// let shopItemsData2 = [
//     {
//         id: 'rretre',
//         name: 'Joggers and hoddy',
//         price: '25',
//         desc : 'Great Combo',
//         img : './images/shoe1.jpg'
//     },
//     {
//         id: 'jggg',
//         name: 'Joggers and hoddy',
//         price: '25',
//         desc : 'Great Combo',
//         img : './images/shoe2.jpg'  
//     },
//     {
//         id: 'hgrjkfk',
//         name: 'Joggers and hoddy',
//         price: '25',
//         desc : 'Great Combo',
//         img : './images/shoe3.jpg'
//     },
//     {
//         id: 'tyyu',
//         name: 'Joggers and hoddy',
//         price: '25',
//         desc : 'Great Combo',
//         img : './images/shoe4.jpg'
//     },
//     {
//         id: 'nnmrlr',
//         name: 'Crazy Hot Joggers ',
//         price: '15',
//         desc : 'Just Fahion',
//         img : './images/shoe5.jpg'
//     },
//     {
//         id: '435yfjf',
//         name: 'Crazy Hot Joggers',
//         price: '15',
//         desc : 'Just Fahion',
//         img : './images/shoe6.jpg'  
//     },
//     {
//         id: 'asdf',
//         name: 'Crazy Hot Joggers',
//         price: '15',
//         desc : 'Just Fahion',
//         img : './images/shoe7.jpg'
//     },
//     {
//         id: 'jklk',
//         name: 'Crazy Hot Joggers',
//         price: '15',
//         desc : 'Just Fahion',
//         img : './images/shoe8.jpg'
//     }
// ]

